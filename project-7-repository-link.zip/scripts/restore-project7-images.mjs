import { inflateRawSync } from 'node:zlib';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';

const archiveUrl =
  'https://raw.githubusercontent.com/devdatwinkle1-cloud/Project-7/main/project-6-repository-link.zip';
const assetRoot = path.resolve('src/assets/images');

const requiredImages = [
  'dubai-skyline.jpg',
  'hero-vessel.jpg',
  'intro-warehouse.jpg',
  'svc-air-freight.jpg',
  'svc-cold-chain.jpg',
  'svc-custom-clearance.jpg',
  'svc-freight-forwarding.jpg',
  'svc-nvocc.jpg',
  'svc-project-cargo.jpg',
  'svc-transportation.jpg',
];

async function allImagesPresent() {
  for (const name of requiredImages) {
    try {
      const stat = await readFile(path.join(assetRoot, name));
      if (stat.length > 0) continue;
    } catch {
      // Missing file: fall through to restore.
    }
    return false;
  }
  return true;
}

async function unpack(buffer, depth = 0) {
  if (depth > 4) throw new Error('Unexpected nested archive depth.');

  let end = buffer.length - 22;
  const min = Math.max(0, buffer.length - 65557);
  while (end >= min && buffer.readUInt32LE(end) !== 0x06054b50) end--;
  if (end < min) throw new Error('Project-7 ZIP archive is invalid.');

  const count = buffer.readUInt16LE(end + 10);
  let offset = buffer.readUInt32LE(end + 16);

  for (let entry = 0; entry < count; entry++) {
    if (buffer.readUInt32LE(offset) !== 0x02014b50) throw new Error('Project-7 ZIP directory is invalid.');

    const method = buffer.readUInt16LE(offset + 10);
    const compressedSize = buffer.readUInt32LE(offset + 20);
    const size = buffer.readUInt32LE(offset + 24);
    const nameLength = buffer.readUInt16LE(offset + 28);
    const extraLength = buffer.readUInt16LE(offset + 30);
    const commentLength = buffer.readUInt16LE(offset + 32);
    const localOffset = buffer.readUInt32LE(offset + 42);
    const name = buffer.subarray(offset + 46, offset + 46 + nameLength).toString('utf8').replaceAll('\\', '/');
    offset += 46 + nameLength + extraLength + commentLength;

    const segments = name.split('/');
    if (name.endsWith('/') || segments.some((part) => part === '..' || part === 'node_modules' || part === '__MACOSX')) {
      continue;
    }

    const localNameLength = buffer.readUInt16LE(localOffset + 26);
    const localExtraLength = buffer.readUInt16LE(localOffset + 28);
    const start = localOffset + 30 + localNameLength + localExtraLength;
    const compressed = buffer.subarray(start, start + compressedSize);
    const content = method === 0 ? compressed : method === 8 ? inflateRawSync(compressed) : null;
    if (!content || content.length !== size) throw new Error(`Could not extract ${name}.`);

    if (name.toLowerCase().endsWith('.zip')) {
      await unpack(content, depth + 1);
      continue;
    }

    const marker = name.lastIndexOf('src/assets/images/');
    if (marker < 0) continue;
    const relativeName = name.slice(marker + 'src/assets/images/'.length);
    if (!relativeName || relativeName.split('/').some((part) => !part || part === '..')) continue;

    const destination = path.resolve(assetRoot, relativeName);
    if (!destination.startsWith(`${assetRoot}${path.sep}`)) throw new Error('Unsafe image path in archive.');

    await mkdir(path.dirname(destination), { recursive: true });
    await writeFile(destination, content);
  }
}

export async function restoreProject7Images() {
  if (await allImagesPresent()) {
    console.log('Project-7 image assets already present.');
    return;
  }

  const response = await fetch(archiveUrl, { signal: AbortSignal.timeout(60000) });
  if (!response.ok) throw new Error(`Could not fetch the Project-7 archive (${response.status}).`);
  await unpack(Buffer.from(await response.arrayBuffer()));

  if (!(await allImagesPresent())) throw new Error('Project-7 image assets were not restored.');
  console.log('Restored the original Project-7 image assets.');
}

// Runs on import, so every build starts with the original assets in place.
await restoreProject7Images();

