import { useEffect, useRef, useState } from "react";
import { Globe } from "lucide-react";

const EXPERIENCE_YEARS = 25;
const COUNT_DURATION_MS = 1800;

export default function ExperienceBadge() {
  const badgeRef = useRef<HTMLDivElement>(null);
  const [years, setYears] = useState(0);

  useEffect(() => {
    const badge = badgeRef.current;
    if (!badge) return;

    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setYears(EXPERIENCE_YEARS);
      return;
    }

    let animationFrame = 0;
    let startedAt: number | null = null;
    let hasStarted = false;

    const tick = (now: number) => {
      if (startedAt === null) startedAt = now;
      const progress = Math.min((now - startedAt) / COUNT_DURATION_MS, 1);
      const easedProgress = 1 - Math.pow(1 - progress, 3);
      setYears(Math.round(easedProgress * EXPERIENCE_YEARS));

      if (progress < 1) {
        animationFrame = window.requestAnimationFrame(tick);
      }
    };

    const startCounting = () => {
      if (hasStarted) return;
      hasStarted = true;
      animationFrame = window.requestAnimationFrame(tick);
    };

    if (!("IntersectionObserver" in window)) {
      startCounting();
      return () => window.cancelAnimationFrame(animationFrame);
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          startCounting();
          observer.disconnect();
        }
      },
      { threshold: 0.55 },
    );

    observer.observe(badge);
    return () => {
      observer.disconnect();
      window.cancelAnimationFrame(animationFrame);
    };
  }, []);

  return (
    <div
      ref={badgeRef}
      className="intro-exp-badge"
      role="img"
      aria-label="25 Years Of Experience"
    >
      <span className="intro-exp-badge__icon" aria-hidden="true">
        <Globe size={38} strokeWidth={1.6} />
      </span>
      <span className="intro-exp-badge__text" aria-hidden="true">
        <strong>{years}</strong>
        <span>Years Of Experience</span>
      </span>
    </div>
  );
}