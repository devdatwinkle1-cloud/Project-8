import { Link } from "react-router-dom";
import { ArrowRight, ChevronRight, Mail, MapPin, Phone } from "lucide-react";
import { company, footerServiceLinks, findService, hq, images, services } from "../data/site";
import { SocialLinks } from "./ui";

const quickLinks = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About Us" },
  { to: "/services", label: "Services" },
  { to: "/contact", label: "Contact Us" },
  { to: "/dubai-branch", label: "Dubai Branch" },
];

export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="container">
        <div className="footer-grid">
          <div className="footer-about">
            <Link to="/" className="footer-logo" aria-label="AAHIL MARITIME PVT. LTD. — home">
              <img src={images.logoLight} alt="AAHIL MARITIME PVT. LTD." />
            </Link>
            <h2>Aahil Shipping &amp; Logistics</h2>
            <span className="footer-heading-line" aria-hidden />
            <p>
              A full-service international freight forwarding and logistics company based in Navi
              Mumbai, India — specialized in import, export and foreign-to-foreign global freight:
              Ocean, Air, Land and Rail, warehousing, NVOCC, project &amp; heavy lift cargo and
              customs brokerage.
            </p>
            <p className="footer-tagline">Import · Export · Foreign to Foreign</p>
            <SocialLinks variant="light" />
          </div>

          <div>
            <h2>Quick Links</h2>
            <span className="footer-heading-line" aria-hidden />
            <div className="footer-links">
              {quickLinks.map((l) => (
                <Link key={l.to} to={l.to}>
                  <ChevronRight size={13} aria-hidden /> {l.label}
                </Link>
              ))}
            </div>
          </div>

          <div>
            <h2>Our Services</h2>
            <span className="footer-heading-line" aria-hidden />
            <div className="footer-links footer-service-links">
              {footerServiceLinks.map((id) => {
                const svc = findService(id) ?? services[0];
                return (
                  <Link key={id} to={`/services?service=${id}`}>
                    <ChevronRight size={13} aria-hidden /> {svc.name}
                  </Link>
                );
              })}
            </div>
          </div>

          <div>
            <h2>Get In Touch</h2>
            <span className="footer-heading-line" aria-hidden />
            <div className="footer-contact">
              <Phone size={16} aria-hidden />
              <div>
                <strong>Call Us</strong>
                {company.phones[0]} / {company.phones[1]}
              </div>
            </div>
            <div className="footer-contact">
              <Mail size={16} aria-hidden />
              <div>
                <strong>Email</strong>
                <a href={`mailto:${hq.email}`}>{hq.email}</a>
              </div>
            </div>
            <div className="footer-contact">
              <MapPin size={16} aria-hidden />
              <div>
                <strong>Head Office</strong>
                <address>
                  {hq.addressLines.map((line) => (
                    <span key={line}>
                      {line}
                      <br />
                    </span>
                  ))}
                </address>
              </div>
            </div>
            <Link to="/dubai-branch" className="footer-dubai">
              Dubai Branch <ArrowRight size={13} aria-hidden />
            </Link>
          </div>
        </div>
      </div>

      <div className="footer-bottom">
        <div className="container footer-bottom-inner">
          <p>
            Copyright © {new Date().getFullYear()} {company.legalName} All rights reserved.
          </p>
          <p>
            Logistics Service Provider
            <a href="https://aahilshipping.com" target="_blank" rel="noreferrer">
              aahilshipping.com
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
}
