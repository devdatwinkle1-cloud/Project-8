import { useEffect, useRef, useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { Building2, ChevronRight, Clock, Mail, Menu, Phone, X } from "lucide-react";
import { company, images } from "../data/site";
import { SocialLinks } from "./ui";

const navItems = [
  { to: "/", label: "Home", end: true },
  { to: "/about", label: "About" },
  { to: "/services", label: "Services" },
  { to: "/contact", label: "Contact" },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const headerRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    const onClick = (e: MouseEvent) => {
      if (headerRef.current && !headerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("keydown", onKey);
    document.addEventListener("mousedown", onClick);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("mousedown", onClick);
    };
  }, [open]);

  const closeMenu = () => setOpen(false);

  return (
    <header className="site-header" ref={headerRef}>
      <div className="topbar">
        <div className="container topbar-inner">
          <div className="topbar-group">
            <a className="topbar-item topbar-email" href={`mailto:${company.email}`}>
              <Mail aria-hidden /> {company.email}
            </a>
            <a className="topbar-item" href={`tel:${company.phones[0].replace(/\s/g, "")}`}>
              <Phone aria-hidden /> {company.phones[0]}
            </a>
          </div>
          <span className="topbar-hours">
            <Clock aria-hidden /> {company.hours}
          </span>
        </div>
      </div>

      <div className="container header-inner">
        <Link to="/" className="brand-logo" aria-label="AAHIL MARITIME PVT. LTD. — home" onClick={closeMenu}>
          <img src={images.logoDark} alt="AAHIL MARITIME PVT. LTD." />
        </Link>

        <nav className="desktop-nav" aria-label="Primary">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) => (isActive ? "active" : "")}
            >
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="header-actions">
          <div className="header-social">
            <SocialLinks variant="dark" />
          </div>
          <Link to="/dubai-branch" className="dubai-button" onClick={closeMenu}>
            <Building2 aria-hidden /> Dubai Branch
          </Link>
          <button
            type="button"
            className="menu-toggle"
            aria-expanded={open}
            aria-controls="mobile-nav"
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X aria-hidden /> : <Menu aria-hidden />}
          </button>
        </div>

        <nav
          id="mobile-nav"
          className={`mobile-nav${open ? " is-open" : ""}`}
          aria-label="Mobile"
        >
          <div className="container mobile-nav-inner">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                onClick={closeMenu}
                className={({ isActive }) => (isActive ? "active" : "")}
              >
                {item.label}
                <ChevronRight size={15} aria-hidden />
              </NavLink>
            ))}
            <Link to="/dubai-branch" className="mobile-dubai-link" onClick={closeMenu}>
              Dubai Branch
              <ChevronRight size={15} aria-hidden />
            </Link>
            <SocialLinks variant="dark" />
          </div>
        </nav>
      </div>
    </header>
  );
}
