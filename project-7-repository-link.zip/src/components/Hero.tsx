import { useEffect, useRef, useState } from "react";
import type { TouchEvent } from "react";
import { Boxes, Plane, Ship, Truck } from "lucide-react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { heroSlides, images } from "../data/site";

const SLIDE_MS = 5000;
const WHEEL_MS = 2600;
const SWIPE_THRESHOLD = 48;
const SWIPE_EASE = [0.22, 1, 0.36, 1] as const;
const EXIT_EASE = [0.4, 0, 1, 1] as const;

interface SlideMotion {
  direction: number;
  reduced: boolean;
}

const slideVariants = {
  hidden: ({ direction, reduced }: SlideMotion) => ({
    x: reduced ? 0 : direction > 0 ? 56 : -56,
    opacity: 0,
    transition: { duration: reduced ? 0 : 0.65, ease: SWIPE_EASE },
  }),
  center: ({ reduced }: SlideMotion) => ({
    x: 0,
    opacity: 1,
    transition: { duration: reduced ? 0 : 0.7, ease: SWIPE_EASE },
  }),
  exit: ({ direction, reduced }: SlideMotion) => ({
    x: reduced ? 0 : direction > 0 ? -56 : 56,
    opacity: 0,
    transition: { duration: reduced ? 0 : 0.5, ease: EXIT_EASE },
  }),
};

/* Background image per slide — advances with the same 5s slide timer */
const slideImages: Record<string, { src: string; alt: string }> = {
  welcome: {
    src: images.heroVessel,
    alt: "Container vessel crossing open water",
  },
  offices: {
    src: images.dubaiSkyline,
    alt: "Dubai trade skyline and port district",
  },
  services: {
    src: images.introWarehouse,
    alt: "Warehouse aisle inside an Aahil logistics facility",
  },
};

const wheelItems = [
  { id: "transportation", label: "Transportation", Icon: Truck },
  { id: "sea-freight", label: "Sea Freight", Icon: Ship },
  { id: "air-freight", label: "Air Freight", Icon: Plane },
  { id: "warehousing", label: "Warehousing", Icon: Boxes },
];

export default function Hero() {
  const [slide, setSlide] = useState({ index: 0, previousIndex: null as number | null, direction: 1 });
  const [paused, setPaused] = useState(false);
  const count = heroSlides.length;
  const [step, setStep] = useState(0);
  const wheelCount = wheelItems.length;
  const wheel = step % wheelCount;
  const reducedMotion = useReducedMotion();
  const touchStartX = useRef<number | null>(null);
  const index = slide.index;

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const timer = window.setInterval(() => setStep((s) => s + 1), WHEEL_MS);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    if (paused) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const timer = window.setInterval(() => {
      setSlide((current) => ({
        index: (current.index + 1) % count,
        previousIndex: current.index,
        direction: 1,
      }));
    }, SLIDE_MS);
    return () => window.clearInterval(timer);
  }, [paused, count]);

  const go = (target: number, direction?: number) => {
    setSlide((current) => {
      const next = ((target % count) + count) % count;
      if (next === current.index) return current;
      return {
        index: next,
        previousIndex: current.index,
        direction: direction ?? (next > current.index ? 1 : -1),
      };
    });
  };

  const handleTouchStart = (event: TouchEvent<HTMLElement>) => {
    touchStartX.current = event.touches[0]?.clientX ?? null;
    setPaused(true);
  };

  const handleTouchEnd = (event: TouchEvent<HTMLElement>) => {
    const startX = touchStartX.current;
    const endX = event.changedTouches[0]?.clientX;
    if (startX !== null && endX !== undefined) {
      const distance = endX - startX;
      if (Math.abs(distance) > SWIPE_THRESHOLD) {
        const direction = distance < 0 ? 1 : -1;
        go(index + direction, direction);
      }
    }
    touchStartX.current = null;
    setPaused(false);
  };

  const handleTouchCancel = () => {
    touchStartX.current = null;
    setPaused(false);
  };

  return (
    <section
      className="hero hero--rotating-services hero--navy"
      aria-roledescription="carousel"
      aria-label="Aahil highlights"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      onTouchCancel={handleTouchCancel}
    >
      {/* Image layer — crossfades every SLIDE_MS (5 seconds) with the active slide */}
      <div className="hero-media" aria-hidden>
        <AnimatePresence initial={false}>
          <motion.img
            key={heroSlides[index].id}
            src={slideImages[heroSlides[index].id].src}
            alt={slideImages[heroSlides[index].id].alt}
            initial={{ opacity: 0, scale: reducedMotion ? 1 : 1.07, x: reducedMotion ? 0 : slide.direction > 0 ? 34 : -34 }}
            animate={{ opacity: 1, scale: 1, x: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: reducedMotion ? 0 : 1.15, ease: SWIPE_EASE }}
          />
        </AnimatePresence>
        <div className="hero-shade" />
      </div>

      {/* Decorative arc ring with the rotating service icon */}
      <div className="hero-orbit" aria-hidden>
        {wheelItems.map((item, i) => {
          const state =
            i === wheel
              ? "is-active"
              : i === (wheel - 1 + wheelCount) % wheelCount
                ? "is-leaving"
                : "is-waiting";
          const gradientId = `heroArcGrad-${item.id}`;
          return (
            <div key={item.id} className={`hero-wheel ${state}`}>
              {/* The circle line travels with its own service label */}
              <svg className="hero-arc" viewBox="0 0 600 600" fill="none">
                <defs>
                  <linearGradient id={gradientId} x1="0" y1="0" x2="0.6" y2="1">
                    <stop offset="0%" stopColor="#ffffff" />
                    <stop offset="100%" stopColor="#0284c7" />
                  </linearGradient>
                </defs>
                <path
                  d="M87.9 102.2 A290 290 0 0 0 22.7 215.2"
                  stroke={`url(#${gradientId})`}
                  strokeWidth="2.4"
                  strokeLinecap="round"
                />
                <path
                  d="M22.7 384.8 A290 290 0 0 0 87.9 497.8"
                  stroke={`url(#${gradientId})`}
                  strokeWidth="2.4"
                  strokeLinecap="round"
                />
              </svg>
              <div className="hero-ghost">
                <item.Icon size={30} strokeWidth={2.2} />
                <span className="hero-ghost-label">{item.label}</span>
              </div>
            </div>
          );
        })}
      </div>

      {heroSlides.map((item, i) => {
        const isActive = i === index;
        const isLeaving = i === slide.previousIndex && !isActive;
        const motionState = isActive ? "center" : isLeaving ? "exit" : "hidden";
        return (
          <motion.div
            key={item.id}
            className={`hero-slide hero-slide--swipe${isActive ? " is-active" : ""}`}
            custom={{ direction: slide.direction, reduced: Boolean(reducedMotion) }}
            variants={slideVariants}
            initial={false}
            animate={motionState}
            role="group"
            aria-roledescription="slide"
            aria-label={`Slide ${i + 1} of ${count}: ${item.badge}`}
            aria-hidden={!isActive}
          >
            <div className="container hero-content">
              <p className="hero-badge">{item.badge}</p>
              {item.variant === "display" ? (
                <h1 className="hero-title--display">{item.title}</h1>
              ) : (
                <h2 className="hero-title--list">{item.title}</h2>
              )}
              {item.tagline && <p className="hero-tagline">{item.tagline}</p>}
              {item.subline && <p className="hero-subline">{item.subline}</p>}
            </div>
          </motion.div>
        );
      })}

    </section>
  );
}
