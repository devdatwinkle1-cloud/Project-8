import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";

interface PageBannerProps {
  eyebrow: string;
  title: string;
  crumb: string;
}

export default function PageBanner({ eyebrow, title, crumb }: PageBannerProps) {
  return (
    <section className="page-banner">
      <div className="container">
        <p className="eyebrow">{eyebrow}</p>
        <h1>{title}</h1>
        <ul className="breadcrumb" aria-label="Breadcrumb">
          <li>
            <Link to="/">Home</Link>
          </li>
          <li aria-hidden>
            <ChevronRight />
          </li>
          <li aria-current="page">{crumb}</li>
        </ul>
      </div>
    </section>
  );
}
