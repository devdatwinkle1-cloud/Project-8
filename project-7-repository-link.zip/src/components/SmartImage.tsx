import { useState, type ImgHTMLAttributes } from "react";

interface SmartImageProps extends ImgHTMLAttributes<HTMLImageElement> {
  /** Local image used when the primary source fails to load. */
  fallbackSrc?: string;
}

export default function SmartImage({ fallbackSrc, src, alt = "", ...rest }: SmartImageProps) {
  const [current, setCurrent] = useState<string>(src ?? "");

  return (
    <img
      src={current}
      alt={alt}
      {...rest}
      onError={() => {
        if (fallbackSrc && current !== fallbackSrc) setCurrent(fallbackSrc);
      }}
    />
  );
}
