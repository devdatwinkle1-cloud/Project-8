import { memo, useEffect, useRef, useState } from "react";
import type { FocusEvent, TouchEvent } from "react";
import { BadgeCheck, ChevronLeft, ChevronRight, Star } from "lucide-react";
import { motion, useReducedMotion } from "motion/react";
import type { Variants } from "motion/react";
import worldMap from "@svg-maps/world";
import { testimonials } from "../data/site";

const AUTOPLAY_MS = 5000;
const SWIPE_THRESHOLD = 48;
const SLIDE_OFFSET = 44;
const EASE = [0.22, 1, 0.36, 1] as const;
/* Frames the map on Europe, Africa and South America, as in the original band */
const MAP_VIEWBOX = "0 150 1010 520";

interface SlideMotion {
  direction: number;
  reduced: boolean;
}

interface MapLocation {
  id: string;
  path: string;
}

const mapLocations: MapLocation[] = worldMap.locations;

const slideVariants: Variants = {
  center: ({ direction, reduced }: SlideMotion) =>
    reduced
      ? { opacity: 1, x: 0, transition: { duration: 0 } }
      : {
          opacity: [0, 1],
          x: [direction * SLIDE_OFFSET, 0],
          transition: { duration: 0.6, ease: EASE },
        },
  exit: ({ direction, reduced }: SlideMotion) => ({
    opacity: 0,
    x: reduced ? 0 : direction * -SLIDE_OFFSET,
    transition: { duration: reduced ? 0 : 0.45, ease: EASE },
  }),
  hidden: { opacity: 0, x: 0, transition: { duration: 0 } },
};

/* Decorative world map drawn as SVG so it stays crisp on every screen */
const WorldMap = memo(function WorldMap() {
  return (
    <svg
      className="testimonial-band__map"
      viewBox={MAP_VIEWBOX}
      preserveAspectRatio="xMidYMid slice"
      aria-hidden="true"
      focusable="false"
    >
      <g>
        {mapLocations.map((location) => (
          <path key={location.id} d={location.path} />
        ))}
      </g>
    </svg>
  );
});

function QuoteMark() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <path
        fill="currentColor"
        d="M9.6 5.2C6.3 6.3 4.3 9.3 4.3 12.9v5.9h6.4v-6.4H7.6c.1-2 1.3-3.7 3.1-4.5l-1.1-2.7zm9.1 0c-3.3 1.1-5.3 4.1-5.3 7.7v5.9h6.4v-6.4h-3.1c.1-2 1.3-3.7 3.1-4.5l-1.1-2.7z"
      />
    </svg>
  );
}

function initials(name: string) {
  return name
    .split(" ")
    .map((w) => w[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

function splitRole(role: string) {
  const [title, company] = role.split(",").map((s) => s.trim());
  return { title: title || role, company: company || "" };
}

export default function Testimonials() {
  const count = testimonials.length;
  const [slide, setSlide] = useState({ index: 0, previous: null as number | null, direction: 1 });
  const [hovered, setHovered] = useState(false);
  const [focused, setFocused] = useState(false);
  const reducedMotion = Boolean(useReducedMotion());
  const touchStartX = useRef<number | null>(null);
  const paused = hovered || focused;
  const { index } = slide;

  const go = (target: number, direction?: number) => {
    setSlide((current) => {
      const next = ((target % count) + count) % count;
      if (next === current.index) return current;
      return {
        index: next,
        previous: current.index,
        direction: direction ?? (next > current.index ? 1 : -1),
      };
    });
  };

  /* Auto-advance every 5 seconds; the timer restarts after each change.
     Runs continuously so the slide always changes on its own. */
  useEffect(() => {
    if (reducedMotion || count < 2) return;
    const timer = window.setInterval(() => {
      setSlide((current) => ({
        index: (current.index + 1) % count,
        previous: current.index,
        direction: 1,
      }));
    }, AUTOPLAY_MS);
    return () => window.clearInterval(timer);
  }, [reducedMotion, count]);

  const handleTouchStart = (event: TouchEvent<HTMLElement>) => {
    touchStartX.current = event.touches[0]?.clientX ?? null;
    setHovered(true);
  };

  const handleTouchEnd = (event: TouchEvent<HTMLElement>) => {
    const startX = touchStartX.current;
    const endX = event.changedTouches[0]?.clientX;
    if (startX !== null && endX !== undefined && Math.abs(endX - startX) > SWIPE_THRESHOLD) {
      const direction = endX < startX ? 1 : -1;
      go(index + direction, direction);
    }
    touchStartX.current = null;
    setHovered(false);
  };

  const handleTouchCancel = () => {
    touchStartX.current = null;
    setHovered(false);
  };

  const handleBlur = (event: FocusEvent<HTMLElement>) => {
    if (!event.currentTarget.contains(event.relatedTarget as Node | null)) {
      setFocused(false);
    }
  };

  const pad = (n: number) => String(n + 1).padStart(2, "0");

  return (
    <section
      className="testimonial-band testimonial-band--new"
      aria-roledescription="carousel"
      aria-labelledby="testimonials-title"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onFocus={() => setFocused(true)}
      onBlur={handleBlur}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      onTouchCancel={handleTouchCancel}
    >
      <WorldMap />
      <span className="testimonial-band__glow testimonial-band__glow--a" aria-hidden="true" />
      <span className="testimonial-band__glow testimonial-band__glow--b" aria-hidden="true" />

      {/* ======= REDESIGNED div.container ======= */}
      <div className="container testimonial-band__inner">
        <div className="testimonial-band__head">
          <div className="testimonial-band__head-copy">
            <p className="testimonial-band__eyebrow">
              <span className="testimonial-band__pulse" aria-hidden="true" />
              Client stories · Rated 5.0 / 5
            </p>
            <h2 id="testimonials-title">What Our Clients Say</h2>
            <p className="testimonial-band__sub">
              Shippers, importers and project teams we have moved cargo with across India, the Gulf
              and beyond.
            </p>
          </div>

          <div className="testimonial-band__controls">
            <span className="testimonial-band__counter" aria-live="polite">
              <strong>{pad(index)}</strong>
              <span aria-hidden="true"> / {pad(count - 1)}</span>
              <span className="sr-only"> of {count} testimonials</span>
            </span>
            <div className="testimonial-band__arrows">
              <button
                type="button"
                className="testimonial-band__arrow"
                aria-label="Previous testimonial"
                onClick={() => go(index - 1, -1)}
              >
                <ChevronLeft aria-hidden />
              </button>
              <button
                type="button"
                className="testimonial-band__arrow testimonial-band__arrow--next"
                aria-label="Next testimonial"
                onClick={() => go(index + 1, 1)}
              >
                <ChevronRight aria-hidden />
              </button>
            </div>
          </div>
        </div>

        <div className="testimonial-band__card">
          <span className="testimonial-band__card-quote" aria-hidden="true">
            <QuoteMark />
          </span>

          <div className="testimonial-band__track" aria-live={paused || reducedMotion ? "polite" : "off"}>
            {testimonials.map((t, i) => {
              const isActive = i === index;
              const state = isActive ? "center" : i === slide.previous ? "exit" : "hidden";
              const { title, company } = splitRole(t.role);
              return (
                <motion.figure
                  key={t.name}
                  className={`testimonial-band__slide${isActive ? " is-active" : ""}`}
                  role="group"
                  aria-roledescription="slide"
                  aria-label={`${i + 1} of ${count}`}
                  aria-hidden={!isActive}
                  custom={{ direction: slide.direction, reduced: reducedMotion }}
                  variants={slideVariants}
                  initial={false}
                  animate={state}
                >
                  <div className="testimonial-band__person">
                    <span className="testimonial-band__avatar" aria-hidden="true">
                      <span className="testimonial-band__avatar-ring">
                        {initials(t.name)}
                      </span>
                      <span className="testimonial-band__badge">
                        <QuoteMark />
                      </span>
                    </span>
                    <span className="testimonial-band__who">
                      <strong>
                        {t.name}
                        <BadgeCheck className="testimonial-band__verified" aria-label="Verified client" />
                      </strong>
                      <span className="testimonial-band__role">{title}</span>
                      {company ? (
                        <span className="testimonial-band__company">{company}</span>
                      ) : null}
                    </span>
                    <span
                      className="testimonial-band__stars"
                      role="img"
                      aria-label="Rated 5 out of 5"
                    >
                      {[0, 1, 2, 3, 4].map((star) => (
                        <Star key={star} aria-hidden fill="currentColor" strokeWidth={1.2} />
                      ))}
                    </span>
                  </div>

                  <blockquote className="testimonial-band__quote">
                    <p>“{t.quote}”</p>
                  </blockquote>
                </motion.figure>
              );
            })}
          </div>

          <div className="testimonial-band__foot">
            <div
              className="testimonial-band__progress"
              aria-hidden="true"
              data-paused={paused || reducedMotion ? "true" : "false"}
            >
              <span key={index} />
            </div>
            <div className="testimonial-band__dots" role="group" aria-label="Choose a testimonial">
              {testimonials.map((t, i) => (
                <button
                  key={t.name}
                  type="button"
                  className={i === index ? "is-active" : ""}
                  aria-label={`Show testimonial ${i + 1} of ${count}: ${t.name}`}
                  aria-current={i === index ? "true" : undefined}
                  onClick={() => go(i)}
                >
                  <span aria-hidden />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
