import type { ReactNode } from "react";
import { Link } from "react-router-dom";
import {
  Ship,
  Container,
  Plane,
  Stamp,
  Truck,
  Snowflake,
  Construction,
  Globe,
  Target,
  ShieldCheck,
  Handshake,
} from "lucide-react";
import type { ServiceIcon } from "../data/site";
import { socials } from "../data/site";

export function ServiceGlyph({ icon, size = 22 }: { icon: ServiceIcon; size?: number }) {
  switch (icon) {
    case "ship":
      return <Ship size={size} aria-hidden />;
    case "container":
      return <Container size={size} aria-hidden />;
    case "plane":
      return <Plane size={size} aria-hidden />;
    case "stamp":
      return <Stamp size={size} aria-hidden />;
    case "truck":
      return <Truck size={size} aria-hidden />;
    case "snowflake":
      return <Snowflake size={size} aria-hidden />;
    case "crane":
      return <Construction size={size} aria-hidden />;
  }
}

export function PrincipleGlyph({ icon, size = 23 }: { icon: string; size?: number }) {
  switch (icon) {
    case "globe":
      return <Globe size={size} aria-hidden />;
    case "target":
      return <Target size={size} aria-hidden />;
    case "shield":
      return <ShieldCheck size={size} aria-hidden />;
    case "handshake":
      return <Handshake size={size} aria-hidden />;
    default:
      return <Globe size={size} aria-hidden />;
  }
}

export function SocialLinks({ variant = "dark" }: { variant?: "dark" | "light" }) {
  const stroke = {
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  };
  const iconFor = (id: string) => {
    switch (id) {
      case "linkedin":
        return (
          <svg width="14" height="14" viewBox="0 0 24 24" {...stroke} aria-hidden>
            <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4V8h4v1.5" />
            <rect x="2" y="9" width="4" height="12" />
            <circle cx="4" cy="4" r="2" />
          </svg>
        );
      case "facebook":
        return (
          <svg width="14" height="14" viewBox="0 0 24 24" {...stroke} aria-hidden>
            <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
          </svg>
        );
      case "twitter":
        return (
          <svg width="14" height="14" viewBox="0 0 24 24" {...stroke} aria-hidden>
            <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z" />
          </svg>
        );
      case "instagram":
        return (
          <svg width="14" height="14" viewBox="0 0 24 24" {...stroke} aria-hidden>
            <rect x="2" y="2" width="20" height="20" rx="5" />
            <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
            <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
          </svg>
        );
      default:
        return <Globe size={14} aria-hidden />;
    }
  };

  return (
    <div className={`social-links${variant === "light" ? " social-links--light" : ""}`}>
      {socials.map((s) => (
        <a key={s.id} href={s.url} target="_blank" rel="noreferrer" aria-label={s.label} title={s.label}>
          {iconFor(s.id)}
        </a>
      ))}
    </div>
  );
}

interface LinkButtonProps {
  to: string;
  children: ReactNode;
  variant?: "solid" | "outline" | "light" | "coral";
  small?: boolean;
  withArrow?: boolean;
}

export function LinkButton({ to, children, variant = "solid", small, withArrow }: LinkButtonProps) {
  const cls = [
    "button",
    variant === "outline" ? "button--outline" : "",
    variant === "light" ? "button--light" : "",
    variant === "coral" ? "button--coral" : "",
    small ? "button--sm" : "",
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <Link to={to} className={cls}>
      {children}
      {withArrow && (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
          <path d="M5 12h14" />
          <path d="m13 6 6 6-6 6" />
        </svg>
      )}
    </Link>
  );
}

export function Section({
  id,
  children,
  className = "",
  tight,
}: {
  id?: string;
  children: ReactNode;
  className?: string;
  tight?: boolean;
}) {
  return (
    <section id={id} className={`section${tight ? " section--tight" : ""}${className ? ` ${className}` : ""}`}>
      {children}
    </section>
  );
}
