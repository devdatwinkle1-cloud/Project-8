import heroVessel from "../assets/images/hero-vessel.jpg";
import introWarehouse from "../assets/images/intro-warehouse.jpg";
import dubaiSkyline from "../assets/images/dubai-skyline.jpg";
import svcNvocc from "../assets/images/svc-nvocc.jpg";
import svcFreightForwarding from "../assets/images/svc-freight-forwarding.jpg";
import svcAirFreight from "../assets/images/svc-air-freight.jpg";
import svcCustomClearance from "../assets/images/svc-custom-clearance.jpg";
import svcTransportation from "../assets/images/svc-transportation.jpg";
import svcColdChain from "../assets/images/svc-cold-chain.jpg";
import svcProjectCargo from "../assets/images/svc-project-cargo.jpg";
import aahilLogoDark from "../assets/images/aahil-logo.svg";
import aahilLogoLight from "../assets/images/aahil-maritime-light.svg";

export const images = {
  heroVessel,
  introWarehouse,
  dubaiSkyline,
  logoDark: aahilLogoDark,
  logoLight: aahilLogoLight,
};

export const company = {
  name: "AAHIL MARITIME PVT. LTD.",
  legalName: "Aahil Shipping and Logistics Pvt. Ltd.",
  shortName: "Aahil Shipping & Logistics",
  established: 2018,
  email: "info@aahilshipping.com",
  phones: ["+91 88981 44307", "+91 22 4013 9773"],
  hours: "Mon – Sat | 9:30 AM – 5:30 PM",
  intro:
    "AAHIL SHIPPING & LOGISTICS is a full-service international freight forwarding and logistics company based in Navi Mumbai, INDIA specialized in import, export and foreign to foreign global freight and logistics services including: Ocean, Air, Land and Rail Freight, warehousing, NVOCC, project and heavy lift cargo, and customs brokerage services.",
  introMore:
    "We have been on the forefront of providing services into niche markets worldwide. With a branch network across India and a presence in Dubai, we keep our clients' cargo moving on the most economical and reliable route — with documentation, tracking and compliance handled end to end.",
};

export const hq = {
  name: "Head Office – Navi Mumbai",
  addressLines: [
    "706 – 710 Shree NandDham Bldg, B Wing",
    "Above Indusind Bank, Sector 11, CBD Belapur",
    "Navi Mumbai – 400614, Maharashtra, India",
  ],
  phone: "+91 88981 44307",
  altPhone: "+91 22 4013 9773",
  email: "info@aahilshipping.com",
  hours: "Mon – Sat | 9:30 AM – 5:30 PM",
  mapQuery: "Shree Nand Dham, Sector 11, CBD Belapur, Navi Mumbai, Maharashtra, India",
};

export const dubai = {
  name: "Dubai Branch",
  addressLines: [
    "Office 1402, 14th Floor, Business Park Tower",
    "Al Jurf 1, Dubai – 506002",
    "United Arab Emirates",
  ],
  phone: "+971 4 553 0148",
  email: "info@aahilshipping.com",
  hours: "Sun – Thu | 9:00 AM – 6:00 PM",
  mapQuery: "Al Jurf 1, Dubai, United Arab Emirates",
};

export interface Branch {
  name: string;
  region: string;
  address: string;
  email: string;
}

export const branches: Branch[] = [
  {
    name: "Mundra / Kandla / Hazira",
    region: "Gandhidham",
    address:
      "Office No. 05, 1st Floor, OM Corner, Plot No. 336, 337 & 338, Ward 12/B, Gandhidham, Kutch – 370201, Gujarat, India",
    email: "info@aahilshipping.com",
  },
  {
    name: "Nagpur",
    region: "Maharashtra",
    address:
      "Flat No. 406, 4th Floor, Morya Apartment, Near Borkute Layout, Beside Narendra Nagar Ground, Nagpur – 440015, Maharashtra, India",
    email: "info@aahilshipping.com",
  },
  {
    name: "Kanpur",
    region: "Uttar Pradesh",
    address:
      "Office No. 19, Ground Floor, Kanpur Logistics Park Pvt. Ltd., Plot No. 5, Bhatta Area, Rani Gunk Panki, Kanpur – 208020, Uttar Pradesh, India",
    email: "info@aahilshipping.com",
  },
  {
    name: "Kolkata",
    region: "West Bengal",
    address:
      "M.A. Business Centre, Ground Floor, Suite #36, Poddar Point, 113 Park Street, Kolkata – 700016, West Bengal, India",
    email: "info@aahilshipping.com",
  },
];

export type ServiceIcon =
  | "ship"
  | "container"
  | "plane"
  | "stamp"
  | "truck"
  | "snowflake"
  | "crane";

export interface Service {
  id: string;
  name: string;
  short: string;
  tagline: string;
  description: string;
  features: string[];
  image: string;
  icon: ServiceIcon;
}

export const services: Service[] = [
  {
    id: "nvocc",
    name: "NVOCC",
    short: "NVOCC",
    tagline: "Non-Vessel Operating Common Carrier",
    description:
      "Operating as a Non-Vessel Operating Common Carrier, Aahil consolidates full container loads and less-than-container shipments across our partner ocean lines. We issue our own house bills of lading, negotiate consolidated rates and extend sailings so small and medium shippers get FCL-level economics with full carrier protection.",
    features: [
      "House bills of lading issued",
      "FCL & LCL consolidation",
      "Weekly sailings via partner lines",
      "Port-to-port and door-to-door",
      "Container cargo tracking",
      "Competitive consolidated rates",
    ],
    image: svcNvocc,
    icon: "ship",
  },
  {
    id: "freight-forwarding",
    name: "Freight Forwarding",
    short: "Freight Forwarding",
    tagline: "Import, export & foreign-to-foreign",
    description:
      "End-to-end freight forwarding for import, export and foreign-to-foreign trade. From pickup at the consignor's facility to final delivery, we plan the route, consolidate equipment, prepare customs documentation and keep you informed at every checkpoint of the journey.",
    features: [
      "Door-to-door coordination",
      "Route & mode planning",
      "Documentation & compliance",
      "Cargo insurance guidance",
      "Milestone tracking reports",
      "Dedicated account managers",
    ],
    image: svcFreightForwarding,
    icon: "container",
  },
  {
    id: "air-freight",
    name: "Air Freight",
    short: "Air Freight",
    tagline: "Time-critical cargo, flown safely",
    description:
      "Time-critical, high-value and perishable cargo moved on scheduled and chartered air services out of Mumbai and secondary airports. Our air desk negotiates weekly contracts with major carriers and special cargo teams, with ULD booking, security and customs handled in-house.",
    features: [
      "Scheduled & charter capacity",
      "Weekly carrier contracts",
      "ULD & airway bill handling",
      "Dangerous goods expertise",
      "Priority customs clearance",
      "Door-to-door air solutions",
    ],
    image: svcAirFreight,
    icon: "plane",
  },
  {
    id: "custom-clearance",
    name: "Custom Clearance",
    short: "Custom Clearance",
    tagline: "Licensed customs brokerage",
    description:
      "As a licensed customs broker we clear imports and exports through Indian and UAE customs with minimal dwell time. Our clearance desk handles classification, valuation, DGFT documentation, bonds and audits so your cargo never waits at the gate or the ramp.",
    features: [
      "Import & export clearance",
      "IEC, DGFT & AD Code support",
      "Bonded warehouse handling",
      "Classification & valuation",
      "Refund & rebate processing",
      "Faster turnaround at Nhava Sheva",
    ],
    image: svcCustomClearance,
    icon: "stamp",
  },
  {
    id: "transportation",
    name: "Transportation",
    short: "Transportation",
    tagline: "Land freight across India & the Gulf",
    description:
      "A dependable land transport network connecting ports, industrial belts and inland destinations across India and the Gulf. Fleet options range from FTL and LTL trucks to flatbeds and hi-payload riggers, all GPS-tracked and covered against loss or damage.",
    features: [
      "FTL & LTL trucking",
      "Flatbed & hi-payload riggers",
      "GPS fleet tracking",
      "Port, yard & plant transfers",
      "Inland container movement",
      "Invoiced fuel & toll management",
    ],
    image: svcTransportation,
    icon: "truck",
  },
  {
    id: "cold-chain",
    name: "Cold Chain",
    short: "Cold Chain",
    tagline: "Temperature-controlled logistics",
    description:
      "Unbroken temperature control for perishable food, pharma and specialised cargo. We manage reefer containers, pre-cooling, monitoring units and bonded cold storage at every handover, with temperature logs delivered with each shipment.",
    features: [
      "Reefer container booking",
      "Pre-cooling & set-point control",
      "Continuous temperature logging",
      "Bonded cold storage access",
      "Pharma-grade handling",
      "Farm & factory gate pickups",
    ],
    image: svcColdChain,
    icon: "snowflake",
  },
  {
    id: "project-cargo",
    name: "Project & Heavy Lift Cargo",
    short: "Project Cargo",
    tagline: "Oversized cargo, engineered delivery",
    description:
      "Project cargo is a term used to broadly describe the national or international transportation of oversized, out-of-gauge and exceptionally heavy equipment. Our project team engineers lift plans, permits and escort logistics for wind, oil & gas, power and industrial projects worldwide.",
    features: [
      "Lift & routing studies",
      "Permits, escorts & surveys",
      "Breakbulk & heavy lift vessels",
      "Site delivery & unloading",
      "Wind, EPC & O&G experience",
      "Single-window project management",
    ],
    image: svcProjectCargo,
    icon: "crane",
  },
];

export function findService(id: string | null | undefined): Service | undefined {
  if (!id) return undefined;
  return services.find((s) => s.id === id);
}

export interface HeroSlide {
  id: string;
  badge: string;
  variant: "display" | "list";
  title: string;
  tagline?: string;
  subline?: string;
  ghost: { icon: ServiceIcon; label: string };
}

export const heroSlides: HeroSlide[] = [
  {
    id: "welcome",
    badge: "Welcome To",
    variant: "display",
    title: "Aahil Maritime",
    tagline: "On Time, On Task, On the Move",
    ghost: { icon: "truck", label: "Transportation" },
  },
  {
    id: "offices",
    badge: "Our Offices",
    variant: "list",
    title:
      "Mumbai – Mundra – Hazira, Kandla – Ahmedabad – Raipur, Chennai – All Major ICDs",
    subline: "Dubai – Chittagong – Dhaka",
    ghost: { icon: "truck", label: "Transportation" },
  },
  {
    id: "services",
    badge: "Our Services",
    variant: "list",
    title:
      "Freight Forwarding, Sea Freight, Air Freight, Liner Agency, Project Cargo, LCL, Ware Housing & 3PL, Custom Clearance, Container Trading",
    ghost: { icon: "plane", label: "Air Freight" },
  },
];

export interface StatItem {
  value: string;
  label: string;
  description: string;
  icon: "calendar" | "layers" | "map-pin" | "users";
}

export const stats: StatItem[] = [
  {
    value: "8+",
    label: "Years of Freight Service",
    description: "Delivering reliable global cargo logistics since 2018",
    icon: "calendar",
  },
  {
    value: "7",
    label: "Core Logistics Services",
    description: "NVOCC, Sea, Air, Land, Cold Chain, Customs & Project",
    icon: "layers",
  },
  {
    value: "6",
    label: "Offices Across India & UAE",
    description: "Mumbai, Mundra, Nagpur, Kanpur, Kolkata & Dubai",
    icon: "map-pin",
  },
  {
    value: "50+",
    label: "Logistics Professionals",
    description: "Dedicated freight managers & customs clearing brokers",
    icon: "users",
  },
];

export const homeHighlights = [
  {
    number: "01",
    title: "Cargo",
    text: "Team of cargo experts are always available to help you with any queries — from classification and packing to final delivery.",
  },
  {
    number: "02",
    title: "Logistics Service",
    text: "We provide logistics services across the nation, whether it is freight transportation, warehousing or end-to-end forwarding.",
  },
  {
    number: "03",
    title: "Project Cargo",
    text: "Project cargo is a term used to broadly describe the national or international movement of oversized, heavy-lift equipment.",
  },
];

export const principles = [
  {
    title: "Global Network, Local Hands",
    text: "Branches at Mundra, Kandla, Hazira, Nagpur, Kanpur, Kolkata and a Dubai office let us work your cargo in the local language, currency and regulation.",
    icon: "globe",
  },
  {
    title: "Niche Market Focus",
    text: "We have been on the forefront of providing services into niche markets worldwide — project cargo, cold chain and specialist commodities.",
    icon: "target",
  },
  {
    title: "Regulatory Precision",
    text: "Licensed NVOCC and customs brokerage, DGFT-compliant documentation and bonded handling keep your shipments clean at every border.",
    icon: "shield",
  },
  {
    title: "Transparent Partnership",
    text: "One accountable account manager, milestone tracking reports and rates that stay exactly as quoted — no surprises mid-journey.",
    icon: "handshake",
  },
];

export const vision =
  "To be the most trusted freight forwarding and logistics partner for Indian and Gulf trade — recognised for moving the cargo others call impossible, with the discipline of a carrier and the care of a family business.";

export const mission =
  "We commit to delivering import, export and foreign-to-foreign freight with unmatched reliability: the right route, clean documentation, honest pricing and a team that answers when you call — from Nhava Sheva to Jebel Ali.";

export interface Testimonial {
  quote: string;
  name: string;
  role: string;
}

export const testimonials: Testimonial[] = [
  {
    quote:
      "Aahil Shipping & Logistics team members helped our company complete the shipment clearance and delivery to various Distribution Line sites.",
    name: "Smith Shah",
    role: "Procurement Head, Defence Supplies",
  },
  {
    quote: "Thanks you for the great customer service, have a great Day!",
    name: "Dinesh Aarya",
    role: "Export Manager, Agro Commodities",
  },
  {
    quote:
      "Their project cargo team moved our heavy industrial equipment from Mundra to site with zero damage, full escort permits and documentation that cleared customs the same day.",
    name: "Rakesh Malhotra",
    role: "Operations Lead, EPC Contractor",
  },
];

export const dubaiNetwork: { title: string; text: string; icon: ServiceIcon }[] = [
  {
    title: "India – Gulf Sea Lane",
    text: "Weekly consolidated sailings between Nhava Sheva, Mundra, Kandla and Jebel Ali, with house bills of lading issued from Dubai.",
    icon: "ship",
  },
  {
    title: "Gulf Air Corridor",
    text: "Priority air capacity out of Dubai to Mumbai and secondary Indian airports for time-critical industrial spares and pharma.",
    icon: "plane",
  },
  {
    title: "Transit & Trade Facilitation",
    text: "Foreign-to-foreign transit, bonded storage at Al Jurf and customs brokerage on both sides of the India–UAE corridor.",
    icon: "stamp",
  },
  {
    title: "Project Cargo Gateway",
    text: "Jebel Ali as the staging port for mega-lift and breakbulk cargo destined for Indian EPC, power and O&G sites.",
    icon: "crane",
  },
];

export const socials = [
  { id: "linkedin", label: "LinkedIn", url: "https://www.linkedin.com/company/aahil-shipping-and-logistics" },
  { id: "facebook", label: "Facebook", url: "https://www.facebook.com/aahilshipping" },
  { id: "twitter", label: "X (Twitter)", url: "https://twitter.com/aahilshipping" },
  { id: "instagram", label: "Instagram", url: "https://www.instagram.com/aahilshipping" },
];

export const footerServiceLinks = [
  "nvocc",
  "freight-forwarding",
  "air-freight",
  "custom-clearance",
  "transportation",
  "cold-chain",
  "project-cargo",
];
