export type OfficeId = "mumbai" | "dubai";

export interface EnquiryInput {
  name: string;
  email: string;
  phone: string;
  service: string;
  office: OfficeId;
  message: string;
  consent: boolean;
}

export type EnquiryErrors = Partial<
  Record<"name" | "email" | "phone" | "service" | "office" | "message" | "consent", string>
>;

export const MESSAGE_MIN = 20;
export const MESSAGE_MAX = 1000;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const PHONE_RE = /^\+?[0-9][0-9\s\-()]{6,18}$/;

export function validateEnquiry(input: EnquiryInput, validServices: string[]): EnquiryErrors {
  const errors: EnquiryErrors = {};
  const name = input.name.trim();
  const email = input.email.trim();
  const phone = input.phone.trim();
  const message = input.message.trim();

  if (!name) {
    errors.name = "Please enter your full name.";
  } else if (name.length < 2) {
    errors.name = "Name must be at least 2 characters long.";
  }

  if (!email) {
    errors.email = "Please enter your email address.";
  } else if (!EMAIL_RE.test(email)) {
    errors.email = "Please enter a valid email address, e.g. name@company.com.";
  }

  if (phone && !PHONE_RE.test(phone)) {
    errors.phone = "Please enter a valid telephone number (digits, spaces, +, - only).";
  }

  if (!input.service) {
    errors.service = "Please select the service you enquire about.";
  } else if (validServices.length && !validServices.includes(input.service)) {
    errors.service = "The selected service is not available.";
  }

  if (input.office !== "mumbai" && input.office !== "dubai") {
    errors.office = "Please select which office should handle your enquiry.";
  }

  if (!message) {
    errors.message = "Please tell us a little about your shipment.";
  } else if (message.length < MESSAGE_MIN) {
    errors.message = `Message must be at least ${MESSAGE_MIN} characters (currently ${message.length}).`;
  } else if (message.length > MESSAGE_MAX) {
    errors.message = `Message must be no longer than ${MESSAGE_MAX} characters (currently ${message.length}).`;
  }

  if (!input.consent) {
    errors.consent = "Please confirm you agree to be contacted about your enquiry.";
  }

  return errors;
}

export function officeMeta(office: OfficeId) {
  return office === "dubai"
    ? {
        id: office,
        label: "Dubai Branch",
        email: "info@aahilshipping.com",
        phone: "+971 4 553 0148",
        address:
          "Office 1402, 14th Floor, Business Park Tower, Al Jurf 1, Dubai – 506002, United Arab Emirates",
      }
    : {
        id: office,
        label: "Head Office – Navi Mumbai",
        email: "info@aahilshipping.com",
        phone: "+91 88981 44307",
        address:
          "706 – 710 Shree NandDham Bldg, B Wing, Above Indusind Bank, Sector 11, CBD Belapur, Navi Mumbai – 400614, Maharashtra, India",
      };
}

export function buildEnquirySubject(serviceName: string, office: OfficeId): string {
  return `Freight Enquiry${office === "dubai" ? " (Dubai Branch)" : ""} – ${serviceName}`;
}

export function buildEnquiryBody(input: EnquiryInput, serviceName: string): string {
  const office = officeMeta(input.office);
  const lines = [
    "New freight enquiry from aahilshipping website",
    "----------------------------------------",
    "",
    `Name:          ${input.name.trim()}`,
    `Email:         ${input.email.trim()}`,
    `Telephone:     ${input.phone.trim() ? input.phone.trim() : "Not provided"}`,
    `Service:       ${serviceName}`,
    `Office:        ${office.label}`,
    "",
    "Shipment details:",
    input.message.trim(),
    "",
    "----------------------------------------",
    "Please reply to the email address above. Thank you.",
  ];
  return lines.join("\n");
}

export function buildEnquiryText(input: EnquiryInput, serviceName: string): string {
  const office = officeMeta(input.office);
  return [
    "AAHIL MARITIME PVT. LTD. – FREIGHT ENQUIRY",
    "==========================================",
    "",
    buildEnquiryBody(input, serviceName),
    "",
    `Send to: ${office.email} (${office.phone})`,
  ].join("\n");
}

export function buildMailtoLink(input: EnquiryInput, serviceName: string): string {
  const office = officeMeta(input.office);
  const subject = buildEnquirySubject(serviceName, input.office);
  const body = buildEnquiryBody(input, serviceName);
  return `mailto:${office.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}
