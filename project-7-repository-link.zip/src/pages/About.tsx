import { useState, type KeyboardEvent } from "react";
import { Compass, Eye } from "lucide-react";
import PageBanner from "../components/PageBanner";
import Reveal from "../components/Reveal";
import SmartImage from "../components/SmartImage";
import ExperienceBadge from "../components/ExperienceBadge";
import { LinkButton, PrincipleGlyph, Section } from "../components/ui";
import {
  company,
  homeHighlights,
  images,
  mission,
  principles,
  vision,
} from "../data/site";

type VmTab = "vision" | "mission";

export default function About() {
  const [tab, setTab] = useState<VmTab>("vision");

  const onTabKey = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key === "ArrowRight" || e.key === "ArrowDown" || e.key === "ArrowLeft" || e.key === "ArrowUp") {
      e.preventDefault();
      setTab((t) => (t === "vision" ? "mission" : "vision"));
    }
  };

  return (
    <>
      <PageBanner
        eyebrow="Who We Are"
        title="About Us"
        crumb="About Us"
      />

      <Section>
        <div className="container">
          <div className="two-column two-column--top">
            <Reveal>
              <div className="intro-photo">
                <SmartImage
                  src={images.introWarehouse}
                  fallbackSrc={images.heroVessel}
                  alt="Aahil logistics operations"
                />
                <ExperienceBadge />
              </div>
            </Reveal>
            <Reveal delay={120}>
              <p className="eyebrow">Company Introduction</p>
              <h2>Moving India &amp; the World&rsquo;s Cargo Since {company.established}</h2>
              <div className="home-about-copy">
                <p>{company.intro}</p>
                <p>{company.introMore}</p>
              </div>
              <div className="about-actions">
                <LinkButton to="/contact" withArrow>
                  Talk to Our Team
                </LinkButton>
                <LinkButton to="/services" variant="outline">
                  Explore Services
                </LinkButton>
              </div>
            </Reveal>
          </div>
        </div>
      </Section>

      <Section className="section--light">
        <div className="container">
          <div className="section-head">
            <p className="eyebrow">How We Work</p>
            <h2>Our Transportation Principles</h2>
            <p>Four commitments that shape every shipment we touch, from a single parcel to a mega-lift.</p>
          </div>
          <div className="principles-grid">
            {principles.map((p, i) => (
              <Reveal key={p.title} delay={i * 80}>
                <div className="principle-card">
                  <div className="principle-card__top">
                    <span className="principle-card__icon" aria-hidden="true">
                      <PrincipleGlyph icon={p.icon} size={22} />
                    </span>
                    <span className="principle-card__number">{String(i + 1).padStart(2, "0")}</span>
                  </div>
                  <h3 className="principle-card__title">{p.title}</h3>
                  <p className="principle-card__desc">{p.text}</p>
                  <span className="principle-card__accent" aria-hidden="true" />
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </Section>

      <Section>
        <div className="container">
          <div className="section-head">
            <p className="eyebrow">What We Commit To</p>
            <h2>Cargo, Logistics &amp; Project Expertise</h2>
          </div>
          <div className="commit-circles">
            <span className="commit-circles__dots commit-circles__dots--left" aria-hidden="true" />
            <span className="commit-circles__dots commit-circles__dots--right" aria-hidden="true" />
            <svg
              className="commit-circles__trail"
              viewBox="0 0 1200 320"
              preserveAspectRatio="none"
              aria-hidden="true"
              focusable="false"
            >
              <path
                d="M-20 150 C 130 150, 200 120, 330 150 S 520 250, 660 250 S 900 150, 1030 140 S 1160 130, 1240 170"
                fill="none"
                stroke="#c9d3de"
                strokeWidth="2"
                strokeDasharray="7 9"
                strokeLinecap="round"
              />
            </svg>

            <div className="commit-circles__grid">
              {homeHighlights.map((h, i) => (
                <Reveal key={h.number} delay={i * 90}>
                  <div className="commit-circle">
                    <span className="commit-circle__badge" aria-hidden="true">
                      {h.number}
                    </span>
                    <div className="commit-circle__ring">
                      <div className="commit-circle__inner">
                        <h3>{h.title}</h3>
                        <p>{h.text}</p>
                      </div>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </Section>

      <Section className="section--light">
        <div className="container">
          <div className="section-head">
            <p className="eyebrow">Why We Exist</p>
            <h2>Vision &amp; Mission</h2>
          </div>
          <Reveal>
            <div className="vm-tabs">
              <div
                className="vm-tablist"
                role="tablist"
                aria-label="Vision and Mission"
                onKeyDown={onTabKey}
              >
                <button
                  type="button"
                  role="tab"
                  id="vm-tab-vision"
                  aria-selected={tab === "vision"}
                  aria-controls="vm-panel"
                  className={`vm-tab${tab === "vision" ? " is-active" : ""}`}
                  onClick={() => setTab("vision")}
                >
                  <Compass aria-hidden /> Vision
                </button>
                <button
                  type="button"
                  role="tab"
                  id="vm-tab-mission"
                  aria-selected={tab === "mission"}
                  aria-controls="vm-panel"
                  className={`vm-tab${tab === "mission" ? " is-active" : ""}`}
                  onClick={() => setTab("mission")}
                >
                  <Eye aria-hidden /> Mission
                </button>
              </div>
              <div
                className="vm-panel"
                role="tabpanel"
                id="vm-panel"
                aria-labelledby={tab === "vision" ? "vm-tab-vision" : "vm-tab-mission"}
              >
                <h3>{tab === "vision" ? "Our Vision" : "Our Mission"}</h3>
                <p>{tab === "vision" ? vision : mission}</p>
              </div>
            </div>
          </Reveal>
        </div>
      </Section>
    </>
  );
}
