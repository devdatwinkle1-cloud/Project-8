import { useState, type FormEvent } from "react";
import { useSearchParams } from "react-router-dom";
import {
  AlertCircle,
  Building2,
  CheckCircle2,
  Download,
  Mail,
  MapPin,
  Phone,
  Send,
} from "lucide-react";
import PageBanner from "../components/PageBanner";
import Reveal from "../components/Reveal";
import { LinkButton, Section } from "../components/ui";
import { branches, company, dubai, findService, hq, services } from "../data/site";
import {
  buildEnquiryText,
  buildMailtoLink,
  officeMeta,
  validateEnquiry,
  MESSAGE_MAX,
  MESSAGE_MIN,
  type EnquiryErrors,
  type OfficeId,
} from "../lib/enquiry";

interface FormState {
  name: string;
  email: string;
  phone: string;
  service: string;
  office: OfficeId;
  message: string;
  consent: boolean;
}

interface SentState {
  mailto: string;
  text: string;
  name: string;
  serviceName: string;
  office: OfficeId;
}

export default function Contact() {
  const [params] = useSearchParams();
  const preService = findService(params.get("service"))?.id ?? "";
  const preOffice: OfficeId = params.get("office") === "dubai" ? "dubai" : "mumbai";

  const [form, setForm] = useState<FormState>({
    name: "",
    email: "",
    phone: "",
    service: preService,
    office: preOffice,
    message: "",
    consent: false,
  });
  const [errors, setErrors] = useState<EnquiryErrors>({});
  const [sent, setSent] = useState<SentState | null>(null);

  const update = (patch: Partial<FormState>) => {
    setForm((f) => ({ ...f, ...patch }));
    if (sent) setSent(null);
  };

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    const errs = validateEnquiry(form, services.map((s) => s.id));
    setErrors(errs);
    if (Object.keys(errs).length > 0) {
      setSent(null);
      return;
    }
    const serviceName = findService(form.service)?.name ?? form.service;
    const mailto = buildMailtoLink(form, serviceName);
    const text = buildEnquiryText(form, serviceName);
    window.location.href = mailto;
    setSent({ mailto, text, name: form.name.trim(), serviceName, office: form.office });
  };

  const downloadText = () => {
    if (!sent) return;
    const blob = new Blob([sent.text], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "aahil-freight-enquiry.txt";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <>
      <PageBanner eyebrow="Get In Touch" title="Contact Us" crumb="Contact" />

      <Section>
        <div className="container">
          <div className="contact-layout">
            <Reveal>
              <p className="eyebrow">Offices</p>
              <h2 style={{ marginBottom: "18px" }}>Head Office &amp; Branches</h2>

              <div className="office-card">
                <span className="office-card-icon" aria-hidden>
                  <Building2 />
                </span>
                <div>
                  <h3>{hq.name}</h3>
                  <address>
                    {hq.addressLines.map((line) => (
                      <span key={line}>
                        {line}
                        <br />
                      </span>
                    ))}
                  </address>
                  <div className="office-lines">
                    <span>
                      <Phone size={13} style={{ verticalAlign: "-2px" }} aria-hidden /> {hq.phone}{" "}
                      / {hq.altPhone}
                    </span>
                    <span>
                      <Mail size={13} style={{ verticalAlign: "-2px" }} aria-hidden />{" "}
                      <a href={`mailto:${hq.email}`}>{hq.email}</a>
                    </span>
                  </div>
                </div>
              </div>

              <div className="office-card">
                <span className="office-card-icon" aria-hidden>
                  <MapPin />
                </span>
                <div>
                  <h3>{dubai.name}</h3>
                  <address>
                    {dubai.addressLines.map((line) => (
                      <span key={line}>
                        {line}
                        <br />
                      </span>
                    ))}
                  </address>
                  <div className="office-lines">
                    <span>
                      <Phone size={13} style={{ verticalAlign: "-2px" }} aria-hidden /> {dubai.phone}
                    </span>
                    <span>
                      <a href="/dubai-branch">Dubai branch details &rarr;</a>
                    </span>
                  </div>
                </div>
              </div>

              <div className="contact-map">
                <iframe
                  title={`Map – ${hq.name}`}
                  src={`https://www.google.com/maps?q=${encodeURIComponent(hq.mapQuery)}&output=embed`}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
                <div className="map-caption">
                  <MapPin aria-hidden /> {hq.addressLines.join(", ")}
                </div>
              </div>

              <h3 style={{ marginTop: "30px", marginBottom: "4px" }}>
                Branch Locations Across India
              </h3>
              <div className="branch-list">
                {branches.map((b) => (
                  <div className="branch" key={b.name}>
                    <h3>{b.name}</h3>
                    <span className="branch-region">{b.region}</span>
                    <address>{b.address}</address>
                  </div>
                ))}
              </div>
            </Reveal>

            <Reveal delay={120}>
              <div className="contact-form">
                {sent ? (
                  <div className="form-success" role="status">
                    <h3>
                      <CheckCircle2 aria-hidden /> Your enquiry is ready to send
                    </h3>
                    <p>
                      Thank you, {sent.name}. Your email application should now be open with the
                      enquiry pre-filled addressed to {officeMeta(sent.office).email} (
                      {officeMeta(sent.office).label}).
                    </p>
                    <p className="success-note">
                      To complete your enquiry, please press <strong>Send</strong> in your email
                      application — we only receive it once you do.
                    </p>
                    <div className="form-success-actions">
                      <a className="button button--sm" href={sent.mailto}>
                        <Send aria-hidden /> Open My Email Application
                      </a>
                      <button
                        type="button"
                        className="button button--outline button--sm"
                        onClick={downloadText}
                      >
                        <Download aria-hidden /> Download Enquiry Text
                      </button>
                      <button
                        type="button"
                        className="button button--outline button--sm"
                        onClick={() => setSent(null)}
                      >
                        Edit Enquiry
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    <h2>Send an Enquiry</h2>
                    <p className="form-intro">
                      Tell us about your shipment and we will respond with a route plan and
                      indicative rates. Your message opens in your own email application.
                    </p>
                    <form onSubmit={onSubmit} noValidate>
                      <div className="form-grid">
                        <div className={`form-field${errors.name ? " has-error" : ""}`}>
                          <label htmlFor="enq-name">Full Name</label>
                          <input
                            id="enq-name"
                            type="text"
                            name="name"
                            autoComplete="name"
                            placeholder="e.g. Rahul Mehta"
                            value={form.name}
                            aria-invalid={!!errors.name}
                            aria-describedby={errors.name ? "enq-name-err" : undefined}
                            onChange={(e) => update({ name: e.target.value })}
                          />
                          {errors.name ? (
                            <span className="field-error" id="enq-name-err" role="alert">
                              <AlertCircle aria-hidden /> {errors.name}
                            </span>
                          ) : null}
                        </div>

                        <div className={`form-field${errors.email ? " has-error" : ""}`}>
                          <label htmlFor="enq-email">Email Address</label>
                          <input
                            id="enq-email"
                            type="email"
                            name="email"
                            autoComplete="email"
                            placeholder="name@company.com"
                            value={form.email}
                            aria-invalid={!!errors.email}
                            aria-describedby={errors.email ? "enq-email-err" : undefined}
                            onChange={(e) => update({ email: e.target.value })}
                          />
                          {errors.email ? (
                            <span className="field-error" id="enq-email-err" role="alert">
                              <AlertCircle aria-hidden /> {errors.email}
                            </span>
                          ) : null}
                        </div>

                        <div className={`form-field${errors.phone ? " has-error" : ""}`}>
                          <label htmlFor="enq-phone">
                            Telephone <span className="optional">(optional)</span>
                          </label>
                          <input
                            id="enq-phone"
                            type="tel"
                            name="phone"
                            autoComplete="tel"
                            placeholder="+91 98765 43210"
                            value={form.phone}
                            aria-invalid={!!errors.phone}
                            aria-describedby={errors.phone ? "enq-phone-err" : undefined}
                            onChange={(e) => update({ phone: e.target.value })}
                          />
                          {errors.phone ? (
                            <span className="field-error" id="enq-phone-err" role="alert">
                              <AlertCircle aria-hidden /> {errors.phone}
                            </span>
                          ) : null}
                        </div>

                        <div className={`form-field${errors.service ? " has-error" : ""}`}>
                          <label htmlFor="enq-service">Service</label>
                          <select
                            id="enq-service"
                            name="service"
                            value={form.service}
                            aria-invalid={!!errors.service}
                            aria-describedby={errors.service ? "enq-service-err" : undefined}
                            onChange={(e) => update({ service: e.target.value })}
                          >
                            <option value="">Select a service…</option>
                            {services.map((s) => (
                              <option key={s.id} value={s.id}>
                                {s.name}
                              </option>
                            ))}
                          </select>
                          {errors.service ? (
                            <span className="field-error" id="enq-service-err" role="alert">
                              <AlertCircle aria-hidden /> {errors.service}
                            </span>
                          ) : null}
                        </div>

                        <div className={`form-field form-field--full${errors.office ? " has-error" : ""}`}>
                          <label htmlFor="enq-office">Which Office Should Handle This?</label>
                          <select
                            id="enq-office"
                            name="office"
                            value={form.office}
                            aria-invalid={!!errors.office}
                            aria-describedby={errors.office ? "enq-office-err" : undefined}
                            onChange={(e) => update({ office: e.target.value as OfficeId })}
                          >
                            <option value="mumbai">Head Office – Navi Mumbai</option>
                            <option value="dubai">Dubai Branch</option>
                          </select>
                          {errors.office ? (
                            <span className="field-error" id="enq-office-err" role="alert">
                              <AlertCircle aria-hidden /> {errors.office}
                            </span>
                          ) : null}
                        </div>

                        <div className={`form-field form-field--full${errors.message ? " has-error" : ""}`}>
                          <label htmlFor="enq-message">Shipment Details</label>
                          <textarea
                            id="enq-message"
                            name="message"
                            placeholder="Commodity, weight/volume, origin, destination, target dates…"
                            value={form.message}
                            aria-invalid={!!errors.message}
                            aria-describedby={
                              errors.message ? "enq-message-err" : "enq-message-count"
                            }
                            onChange={(e) => update({ message: e.target.value })}
                          />
                          <span className="char-count" id="enq-message-count">
                            {form.message.trim().length}/{MESSAGE_MAX} characters (minimum{" "}
                            {MESSAGE_MIN})
                          </span>
                          {errors.message ? (
                            <span className="field-error" id="enq-message-err" role="alert">
                              <AlertCircle aria-hidden /> {errors.message}
                            </span>
                          ) : null}
                        </div>

                        <div
                          className={`form-consent form-field--full${errors.consent ? " has-error" : ""}`}
                        >
                          <input
                            id="enq-consent"
                            type="checkbox"
                            name="consent"
                            checked={form.consent}
                            aria-invalid={!!errors.consent}
                            aria-describedby={errors.consent ? "enq-consent-err" : undefined}
                            onChange={(e) => update({ consent: e.target.checked })}
                          />
                          <label htmlFor="enq-consent">
                            I agree to be contacted by {company.shortName} about this enquiry and
                            understand my details are used only to respond to it.
                          </label>
                        </div>
                      </div>

                      {errors.consent ? (
                        <span className="field-error" id="enq-consent-err" role="alert" style={{ display: "flex", marginTop: 10 }}>
                          <AlertCircle aria-hidden /> {errors.consent}
                        </span>
                      ) : null}

                      <div className="form-actions" style={{ marginTop: "22px" }}>
                        <button type="submit" className="button">
                          <Send aria-hidden /> Send Enquiry
                        </button>
                        <span className="form-hint">
                          Opens a pre-filled email to {hq.email} — you press send.
                        </span>
                      </div>
                    </form>
                  </>
                )}
              </div>
            </Reveal>
          </div>
        </div>
      </Section>

      <div className="home-cta">
        <div className="container">
          <div className="home-cta-inner">
            <div>
              <p>Prefer to Call?</p>
              <h2>Our Desk Answers Mon – Sat, 9:30 AM – 5:30 PM</h2>
            </div>
            <div className="home-cta-actions">
              <a
                className="button"
                href={`tel:${company.phones[0].replace(/\s/g, "")}`}
              >
                <Phone aria-hidden /> {company.phones[0]}
              </a>
              <LinkButton to="/dubai-branch" variant="outline">
                Dubai Branch
              </LinkButton>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
