import {
  Building2,
  Clock,
  Mail,
  MapPin,
  Phone,
} from "lucide-react";
import PageBanner from "../components/PageBanner";
import Reveal from "../components/Reveal";
import SmartImage from "../components/SmartImage";
import { LinkButton, Section, ServiceGlyph } from "../components/ui";
import { company, dubai, dubaiNetwork, images } from "../data/site";

export default function DubaiBranch() {
  return (
    <>
      <PageBanner eyebrow="Middle East Presence" title="Dubai Branch" crumb="Dubai Branch" />

      <Section>
        <div className="container">
          <Reveal>
            <div className="dubai-hero-strip">
              <SmartImage
                src={images.dubaiSkyline}
                fallbackSrc={images.heroVessel}
                alt="Jebel Ali container port, Dubai"
              />
              <div className="strip-shade">
                <div className="strip-copy">
                  <p className="eyebrow">Al Jurf 1 · Dubai, UAE</p>
                  <h2>Your Window to the Middle East</h2>
                  <p>
                    Our Dubai desk handles the India–Gulf sea and air lanes, Jebel Ali transit and
                    project cargo staging — with the same account team as Navi Mumbai.
                  </p>
                </div>
              </div>
            </div>
          </Reveal>

          <div className="two-column two-column--top">
            <Reveal>
              <p className="eyebrow">Office Details</p>
              <h2 style={{ marginBottom: "18px" }}>Dubai Branch Contact</h2>

              <div className="office-card">
                <span className="office-card-icon" aria-hidden>
                  <Building2 />
                </span>
                <div>
                  <h3>{dubai.name}</h3>
                  <address>
                    {dubai.addressLines.map((line) => (
                      <span key={line}>
                        {line}
                        <br />
                      </span>
                    ))}
                  </address>
                  <div className="office-lines">
                    <span>
                      <Clock size={13} style={{ verticalAlign: "-2px" }} aria-hidden /> {dubai.hours}
                    </span>
                  </div>
                </div>
              </div>

              <div className="office-card">
                <span className="office-card-icon" aria-hidden>
                  <Phone />
                </span>
                <div>
                  <h3>Call or Email</h3>
                  <div className="office-lines">
                    <span>
                      <a href={`tel:${dubai.phone.replace(/\s/g, "")}`}>{dubai.phone}</a>
                    </span>
                    <span>
                      <Mail size={13} style={{ verticalAlign: "-2px" }} aria-hidden />{" "}
                      <a href={`mailto:${dubai.email}`}>{dubai.email}</a>
                    </span>
                    <span>
                      Head Office India: <a href={`tel:${company.phones[0].replace(/\s/g, "")}`}>{company.phones[0]}</a>
                    </span>
                  </div>
                </div>
              </div>

              <div className="contact-map">
                <iframe
                  title={`Map – ${dubai.name}`}
                  src={`https://www.google.com/maps?q=${encodeURIComponent(dubai.mapQuery)}&output=embed`}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
                <div className="map-caption">
                  <MapPin aria-hidden /> {dubai.addressLines.join(", ")}
                </div>
              </div>
            </Reveal>

            <Reveal delay={120}>
              <p className="eyebrow">Service Network</p>
              <h2 style={{ marginBottom: "18px" }}>How Dubai Serves Your Trade</h2>
              <div className="network-grid">
                {dubaiNetwork.map((n, i) => (
                  <div className="principle-card" key={n.title}>
                    <div className="principle-card__top">
                      <span className="principle-card__icon" aria-hidden="true">
                        <ServiceGlyph icon={n.icon} size={22} />
                      </span>
                      <span className="principle-card__number">{String(i + 1).padStart(2, "0")}</span>
                    </div>
                    <h3 className="principle-card__title">{n.title}</h3>
                    <p className="principle-card__desc">{n.text}</p>
                    <span className="principle-card__accent" aria-hidden="true" />
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </div>
      </Section>

      <div className="home-cta">
        <div className="container">
          <div className="home-cta-inner">
            <div>
              <p>Dubai Desk Enquiry</p>
              <h2>Send Your Shipment Details to Dubai</h2>
            </div>
            <div className="home-cta-actions">
              <LinkButton to="/contact?office=dubai" withArrow>
                Enquire via Dubai
              </LinkButton>
              <LinkButton to="/services" variant="outline">
                All Services
              </LinkButton>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
