import { Link } from "react-router-dom";
import { ArrowRight, Calendar, Check, Layers, MapPin, Users } from "lucide-react";
import Hero from "../components/Hero";
import Testimonials from "../components/Testimonials";
import Reveal from "../components/Reveal";
import SmartImage from "../components/SmartImage";
import ExperienceBadge from "../components/ExperienceBadge";
import { LinkButton, Section, ServiceGlyph } from "../components/ui";
import { branches, company, homeHighlights, images, services, stats } from "../data/site";

export default function Home() {
  return (
    <>
      <Hero />

      <section className="home-stats-section" aria-label="Company at a glance">
        <div className="container">
          <div className="home-stats-cards">
            {stats.map((s, index) => {
              const IconComponent =
                s.icon === "calendar"
                  ? Calendar
                  : s.icon === "layers"
                  ? Layers
                  : s.icon === "map-pin"
                  ? MapPin
                  : Users;

              return (
                <div key={s.label} className="stat-card" style={{ animationDelay: `${index * 80}ms` }}>
                  <div className="stat-card__top">
                    <span className="stat-card__icon" aria-hidden="true">
                      <IconComponent size={22} strokeWidth={2.2} />
                    </span>
                    <span className="stat-card__number">{s.value}</span>
                  </div>
                  <h3 className="stat-card__title">{s.label}</h3>
                  <p className="stat-card__desc">{s.description}</p>
                  <span className="stat-card__accent" aria-hidden="true" />
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <Section>
        <div className="container">
          <div className="two-column">
            <Reveal>
              <div className="intro-photo">
                <SmartImage
                  src={images.introWarehouse}
                  fallbackSrc={images.heroVessel}
                  alt="Inside an Aahil distribution warehouse"
                />
                <ExperienceBadge />
              </div>
            </Reveal>
            <Reveal delay={120}>
              <div className="home-about-copy">
                <p className="eyebrow">About Aahil Shipping &amp; Logistics</p>
                <h2>
                  Full-Service International Freight Forwarding &amp; Logistics
                </h2>
                <p>{company.intro}</p>
                <div className="home-highlights">
                  {homeHighlights.map((h) => (
                    <div key={h.number}>
                      <Check aria-hidden />
                      <div>
                        <strong>{h.title}</strong>
                        <span>{h.text}</span>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="home-about-actions">
                  <LinkButton to="/about" withArrow>
                    More About Us
                  </LinkButton>
                  <LinkButton to="/services" variant="outline">
                    Our Services
                  </LinkButton>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </Section>

      <Section className="section--light">
        <div className="container">
          <div className="section-head">
            <p className="eyebrow">What We Do</p>
            <h2>Logistics Services Built Around Your Cargo</h2>
            <p>
              Seven core services, one accountable team — pick a lane or let us plan the entire
              journey.
            </p>
          </div>
          <div className="home-service-grid service-preview-grid">
            {services.slice(0, 6).map((s, i) => (
              <Reveal key={s.id} delay={(i % 3) * 90}>
                <Link to={`/services?service=${s.id}`} className="home-service-card">
                  <SmartImage
                    src={s.image}
                    fallbackSrc={images.introWarehouse}
                    alt={s.name}
                  />
                  <span className="home-service-icon" aria-hidden>
                    <ServiceGlyph icon={s.icon} size={21} />
                  </span>
                  <div>
                    <h3>{s.name}</h3>
                    <p>{`${s.description.split(". ")[0]}.`}</p>
                    <span>
                      Explore Service <ArrowRight aria-hidden />
                    </span>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </Section>

      <div className="home-network">
        <div className="container">
          <div className="home-network-inner">
            <div>
              <p className="eyebrow">Our Network</p>
              <h2>Branches Across India &amp; Dubai</h2>
            </div>
            <ul>
              <li>Navi Mumbai (HQ)</li>
              {branches.map((b) => (
                <li key={b.name}>{b.name}</li>
              ))}
              <li>Dubai, UAE</li>
            </ul>
            <LinkButton to="/contact" variant="light" withArrow>
              Contact Us
            </LinkButton>
          </div>
        </div>
      </div>

      <div className="home-cta">
        <div className="container">
          <div className="home-cta-inner">
            <div>
              <p>Get a Freight Quote</p>
              <h2>Ready to Move Your Cargo?</h2>
            </div>
            <div className="home-cta-actions">
              <LinkButton to="/contact" withArrow>
                Request a Quote
              </LinkButton>
              <LinkButton to="/services" variant="outline">
                View Services
              </LinkButton>
            </div>
          </div>
        </div>
      </div>

      <Testimonials />
    </>
  );
}
