import type { KeyboardEvent } from "react";
import { useSearchParams } from "react-router-dom";
import { motion } from "motion/react";
import { Check, ChevronRight, Mail } from "lucide-react";
import PageBanner from "../components/PageBanner";
import Reveal from "../components/Reveal";
import SmartImage from "../components/SmartImage";
import { LinkButton, Section, ServiceGlyph } from "../components/ui";
import { company, findService, images, services } from "../data/site";

export default function Services() {
  const [params, setParams] = useSearchParams();
  const active = findService(params.get("service")) ?? services[0];

  const select = (id: string) => {
    const next = new URLSearchParams(params);
    next.set("service", id);
    setParams(next);
  };

  const onSidebarKey = (e: KeyboardEvent<HTMLUListElement>) => {
    const idx = services.findIndex((s) => s.id === active.id);
    let next: number | null = null;
    if (e.key === "ArrowDown") next = (idx + 1) % services.length;
    else if (e.key === "ArrowUp") next = (idx - 1 + services.length) % services.length;
    else if (e.key === "Home") next = 0;
    else if (e.key === "End") next = services.length - 1;
    else return;

    e.preventDefault();
    const target = services[next];
    select(target.id);
    requestAnimationFrame(() => {
      document
        .querySelector<HTMLButtonElement>(`[data-service-btn="${target.id}"]`)
        ?.focus();
    });
  };

  return (
    <>
      <PageBanner eyebrow="What We Do" title="Our Services" crumb="Services" />

      <Section>
        <div className="container">
          <div className="services-layout">
            <Reveal>
              <aside className="service-sidebar" aria-label="Service list">
                <p className="service-sidebar-title">Select a Service</p>
                <ul onKeyDown={onSidebarKey}>
                  {services.map((s) => (
                    <li key={s.id}>
                      <button
                        type="button"
                        data-service-btn={s.id}
                        className={`service-tab${s.id === active.id ? " is-active" : ""}`}
                        aria-current={s.id === active.id ? "true" : undefined}
                        onClick={() => select(s.id)}
                      >
                        <ServiceGlyph icon={s.icon} size={18} />
                        {s.short}
                      </button>
                    </li>
                  ))}
                </ul>
              </aside>
            </Reveal>

            <motion.div
              key={active.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, ease: "easeOut" }}
              className="service-detail"
            >
              <div className="service-media">
                <SmartImage
                  src={active.image}
                  fallbackSrc={images.introWarehouse}
                  alt={active.name}
                />
                <span className="service-icon-float" aria-hidden>
                  <ServiceGlyph icon={active.icon} size={24} />
                </span>
              </div>
              <div className="service-body">
                <span className="service-tagline">{active.tagline}</span>
                <h2>{active.name}</h2>
                <p>{active.description}</p>
                <ul className="service-features">
                  {active.features.map((f) => (
                    <li key={f}>
                      <Check aria-hidden /> {f}
                    </li>
                  ))}
                </ul>
                <div className="service-actions">
                  <LinkButton to={`/contact?service=${active.id}`} withArrow>
                    Enquire for {active.short}
                  </LinkButton>
                  <a
                    className="button button--outline"
                    href={`mailto:${company.email}?subject=${encodeURIComponent(
                      `Freight Enquiry – ${active.name}`
                    )}`}
                  >
                    <Mail aria-hidden /> Email Us Direct
                  </a>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </Section>

      <div className="home-cta">
        <div className="container">
          <div className="home-cta-inner">
            <div>
              <p>Not Sure Which Lane Fits?</p>
              <h2>Let Our Desk Plan the Route</h2>
            </div>
            <div className="home-cta-actions">
              <LinkButton to="/contact" withArrow>
                <ChevronRight aria-hidden /> Request a Quote
              </LinkButton>
              <LinkButton to="/dubai-branch" variant="outline">
                Dubai Branch
              </LinkButton>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
